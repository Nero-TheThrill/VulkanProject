#include "TracyMemory.hpp"

namespace tracy
{

std::atomic<int64_t> memUsage( 0 );

}
